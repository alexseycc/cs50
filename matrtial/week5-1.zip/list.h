/****************************************************************************
 * list.h
 *
 * CC50
 * Gabriel Lima Guimar�es
 *
 * Define um n� (node) de uma linked list com n�meros
 ***************************************************************************/
       

typedef struct node
{
    int n;
    struct node *next;
}
node;
